var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__453e2162._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(60722)
R.m(34091)
module.exports=R.m(34091).exports
