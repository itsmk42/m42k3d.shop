var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/emails/send-order-notification/route.js")
R.c("server/chunks/[root-of-the-server]__674b2afb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(18187)
R.m(78217)
module.exports=R.m(78217).exports
