module.exports=[18622,(e,r,t)=>{r.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},20635,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,r,t)=>{r.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,r,t)=>{r.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18187,(e,r,t)=>{},78217,e=>{"use strict";e.s(["handler",()=>N,"patchFetch",()=>A,"routeModule",()=>w,"serverHooks",()=>C,"workAsyncStorage",()=>k,"workUnitAsyncStorage",()=>S],78217);var r=e.i(47909),t=e.i(74017),a=e.i(96250),o=e.i(59756),n=e.i(61916),s=e.i(69741),i=e.i(16795),d=e.i(87718),l=e.i(95169),p=e.i(47587),c=e.i(66012),u=e.i(70101),g=e.i(26937),m=e.i(10372),h=e.i(93695);e.i(52474);var x=e.i(5232);e.s(["POST",()=>E],82974);var f=e.i(89171);async function v(e,r,t,a){try{let o=process.env.RESEND_API_KEY;if(!o)return console.warn("RESEND_API_KEY not configured. Email not sent."),{success:!1,error:"Email service not configured"};let n=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify({from:"orders@sparklesphere.shop",to:e,subject:r,html:t,text:a})}),s=await n.json();if(!n.ok)return{success:!1,error:s.message||"Failed to send email via Resend"};return{success:!0,messageId:s.id}}catch(e){return console.error("Resend API error:",e),{success:!1,error:e.message}}}async function b(e,r,t,a){try{let o=process.env.SENDGRID_API_KEY;if(!o)return console.warn("SENDGRID_API_KEY not configured. Email not sent."),{success:!1,error:"Email service not configured"};let n=await fetch("https://api.sendgrid.com/v3/mail/send",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify({personalizations:[{to:[{email:e}],subject:r}],from:{email:"orders@sparklesphere.shop",name:"SparkleSphere"},content:[{type:"text/html",value:t},{type:"text/plain",value:a}]})});if(!n.ok){let e=await n.text();return{success:!1,error:e||"Failed to send email via SendGrid"}}return{success:!0,messageId:n.headers.get("x-message-id")||"unknown"}}catch(e){return console.error("SendGrid API error:",e),{success:!1,error:e.message}}}async function y(e,r,t,a){return process.env.RESEND_API_KEY?v(e,r,t,a):process.env.SENDGRID_API_KEY?b(e,r,t,a):(console.warn("No email service configured. Email not sent."),{success:!1,error:"No email service configured. Please set RESEND_API_KEY or SENDGRID_API_KEY."})}async function E(e){try{let r=await e.json();if(!r.customerEmail||!r.orderId||!r.customerName)return f.NextResponse.json({error:"Missing required fields: customerEmail, orderId, customerName"},{status:400});let{subject:t,html:a,text:o}=function(e){let{orderId:r,customerName:t,orderTotal:a,orderStatus:o,trackingNumber:n,orderDate:s}=e,i="",d="",l="";switch(o){case"pending":case"cod-pending":case"upi-pending":i=`Order Confirmed - #${r.slice(0,8).toUpperCase()}`,d="Your order has been received and is being processed.",l="#FFA500";break;case"processing":i=`Order Processing - #${r.slice(0,8).toUpperCase()}`,d="Your order is being prepared for shipment.",l="#3B82F6";break;case"shipped":i=`Order Shipped - #${r.slice(0,8).toUpperCase()}`,d="Your order is on its way!",l="#8B5CF6";break;case"delivered":i=`Order Delivered - #${r.slice(0,8).toUpperCase()}`,d="Your order has been delivered. Thank you for your purchase!",l="#10B981";break;default:i=`Order Update - #${r.slice(0,8).toUpperCase()}`,d=`Your order status has been updated to: ${o}`,l="#6B7280"}let p=`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f9fafb;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
          }
          .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
          }
          .content {
            padding: 30px 20px;
          }
          .status-box {
            background-color: ${l}20;
            border-left: 4px solid ${l};
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
          }
          .status-box p {
            margin: 0;
            color: ${l};
            font-weight: 600;
          }
          .order-details {
            background-color: #f3f4f6;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
          }
          .order-details p {
            margin: 8px 0;
            font-size: 14px;
          }
          .order-details strong {
            color: #1f2937;
          }
          .tracking-info {
            background-color: #f0f9ff;
            border: 1px solid #bfdbfe;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
          }
          .tracking-info p {
            margin: 0;
            font-size: 14px;
          }
          .tracking-number {
            font-family: 'Courier New', monospace;
            font-size: 16px;
            font-weight: bold;
            color: #1e40af;
            margin-top: 8px;
          }
          .footer {
            background-color: #f9fafb;
            padding: 20px;
            text-align: center;
            font-size: 12px;
            color: #6b7280;
            border-top: 1px solid #e5e7eb;
          }
          .button {
            display: inline-block;
            background-color: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 20px 0;
            font-weight: 600;
          }
          .button:hover {
            background-color: #5568d3;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✨ SparkleSphere</h1>
            <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.9;">Order Update</p>
          </div>

          <div class="content">
            <p>Hi ${t},</p>

            <div class="status-box">
              <p>${d}</p>
            </div>

            <div class="order-details">
              <p><strong>Order ID:</strong> #${r.slice(0,8).toUpperCase()}</p>
              <p><strong>Order Date:</strong> ${new Date(s).toLocaleDateString("en-IN",{year:"numeric",month:"long",day:"numeric"})}</p>
              <p><strong>Order Total:</strong> ₹${a.toFixed(2)}</p>
              <p><strong>Status:</strong> <span style="color: ${l}; font-weight: 600; text-transform: capitalize;">${o.replace("-"," ")}</span></p>
            </div>

            ${n?`
              <div class="tracking-info">
                <p><strong>📦 Tracking Information</strong></p>
                <p>Your package is on its way! Track your shipment using the tracking number below:</p>
                <div class="tracking-number">${n}</div>
              </div>
            `:""}

            <p style="margin-top: 30px; color: #6b7280; font-size: 14px;">
              If you have any questions about your order, please don't hesitate to contact us.
            </p>

            <p style="margin-top: 20px;">
              Best regards,<br>
              <strong>The SparkleSphere Team</strong>
            </p>
          </div>

          <div class="footer">
            <p>\xa9 2025 SparkleSphere. All rights reserved.</p>
            <p>This is an automated email. Please do not reply to this message.</p>
          </div>
        </div>
      </body>
    </html>
  `;return{subject:i,html:p,text:`
SparkleSphere - Order Update

Hi ${t},

${d}

Order Details:
- Order ID: #${r.slice(0,8).toUpperCase()}
- Order Date: ${new Date(s).toLocaleDateString("en-IN")}
- Order Total: ₹${a.toFixed(2)}
- Status: ${o.replace("-"," ").toUpperCase()}

${n?`Tracking Number: ${n}`:""}

If you have any questions about your order, please contact us.

Best regards,
The SparkleSphere Team

\xa9 2025 SparkleSphere. All rights reserved.
  `}}(r),n=await y(r.customerEmail,t,a,o);if(!n.success)return console.error("Failed to send email:",n.error),f.NextResponse.json({error:n.error||"Failed to send email",warning:"Email service may not be configured. Check RESEND_API_KEY or SENDGRID_API_KEY."},{status:500});return f.NextResponse.json({success:!0,message:"Email sent successfully",messageId:n.messageId})}catch(e){return console.error("Email API error:",e),f.NextResponse.json({error:e.message||"Internal server error"},{status:500})}}var R=e.i(82974);let w=new r.AppRouteRouteModule({definition:{kind:t.RouteKind.APP_ROUTE,page:"/api/emails/send-order-notification/route",pathname:"/api/emails/send-order-notification",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/emails/send-order-notification/route.ts",nextConfigOutput:"",userland:R}),{workAsyncStorage:k,workUnitAsyncStorage:S,serverHooks:C}=w;function A(){return(0,a.patchFetch)({workAsyncStorage:k,workUnitAsyncStorage:S})}async function N(e,r,a){var f;let v="/api/emails/send-order-notification/route";v=v.replace(/\/index$/,"")||"/";let b=await w.prepare(e,r,{srcPage:v,multiZoneDraftMode:!1});if(!b)return r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:y,params:E,nextConfig:R,isDraftMode:k,prerenderManifest:S,routerServerContext:C,isOnDemandRevalidate:A,revalidateOnlyGenerated:N,resolvedPathname:I}=b,P=(0,s.normalizeAppPath)(v),O=!!(S.dynamicRoutes[P]||S.routes[I]);if(O&&!k){let e=!!S.routes[I],r=S.dynamicRoutes[P];if(r&&!1===r.fallback&&!e)throw new h.NoFallbackError}let T=null;!O||w.isDev||k||(T="/index"===(T=I)?"/":T);let _=!0===w.isDev||!O,D=O&&!_,$=e.method||"GET",U=(0,n.getTracer)(),j=U.getActiveScopeSpan(),q={params:E,prerenderManifest:S,renderOpts:{experimental:{cacheComponents:!!R.experimental.cacheComponents,authInterrupts:!!R.experimental.authInterrupts},supportsDynamicResponse:_,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:null==(f=R.experimental)?void 0:f.cacheLife,isRevalidate:D,waitUntil:a.waitUntil,onClose:e=>{r.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(r,t,a)=>w.onRequestError(e,r,a,C)},sharedContext:{buildId:y}},F=new i.NodeNextRequest(e),H=new i.NodeNextResponse(r),K=d.NextRequestAdapter.fromNodeNextRequest(F,(0,d.signalFromNodeResponse)(r));try{let s=async t=>w.handle(K,q).finally(()=>{if(!t)return;t.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let a=U.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=a.get("next.route");if(o){let e=`${$} ${o}`;t.setAttributes({"next.route":o,"http.route":o,"next.span_name":e}),t.updateName(e)}else t.updateName(`${$} ${e.url}`)}),i=async n=>{var i,d;let l=async({previousCacheEntry:t})=>{try{if(!(0,o.getRequestMeta)(e,"minimalMode")&&A&&N&&!t)return r.statusCode=404,r.setHeader("x-nextjs-cache","REVALIDATED"),r.end("This page could not be found"),null;let i=await s(n);e.fetchMetrics=q.renderOpts.fetchMetrics;let d=q.renderOpts.pendingWaitUntil;d&&a.waitUntil&&(a.waitUntil(d),d=void 0);let l=q.renderOpts.collectedTags;if(!O)return await (0,c.sendResponse)(F,H,i,q.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),r=(0,u.toNodeOutgoingHttpHeaders)(i.headers);l&&(r[m.NEXT_CACHE_TAGS_HEADER]=l),!r["content-type"]&&e.type&&(r["content-type"]=e.type);let t=void 0!==q.renderOpts.collectedRevalidate&&!(q.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&q.renderOpts.collectedRevalidate,a=void 0===q.renderOpts.collectedExpire||q.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:q.renderOpts.collectedExpire;return{value:{kind:x.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:r},cacheControl:{revalidate:t,expire:a}}}}catch(r){throw(null==t?void 0:t.isStale)&&await w.onRequestError(e,r,{routerKind:"App Router",routePath:v,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isRevalidate:D,isOnDemandRevalidate:A})},C),r}},h=await w.handleResponse({req:e,nextConfig:R,cacheKey:T,routeKind:t.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:N,responseGenerator:l,waitUntil:a.waitUntil});if(!O)return null;if((null==h||null==(i=h.value)?void 0:i.kind)!==x.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==h||null==(d=h.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,o.getRequestMeta)(e,"minimalMode")||r.setHeader("x-nextjs-cache",A?"REVALIDATED":h.isMiss?"MISS":h.isStale?"STALE":"HIT"),k&&r.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let f=(0,u.fromNodeOutgoingHttpHeaders)(h.value.headers);return(0,o.getRequestMeta)(e,"minimalMode")&&O||f.delete(m.NEXT_CACHE_TAGS_HEADER),!h.cacheControl||r.getHeader("Cache-Control")||f.get("Cache-Control")||f.set("Cache-Control",(0,g.getCacheControlHeader)(h.cacheControl)),await (0,c.sendResponse)(F,H,new Response(h.value.body,{headers:f,status:h.value.status||200})),null};j?await i(j):await U.withPropagatedContext(e.headers,()=>U.trace(l.BaseServerSpan.handleRequest,{spanName:`${$} ${e.url}`,kind:n.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},i))}catch(r){if(r instanceof h.NoFallbackError||await w.onRequestError(e,r,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isRevalidate:D,isOnDemandRevalidate:A})}),O)throw r;return await (0,c.sendResponse)(F,H,new Response(null,{status:500})),null}}}];

//# sourceMappingURL=%5Broot-of-the-server%5D__674b2afb._.js.map