module.exports=[48962,a=>{a.v("/_next/static/media/icon.d240b2a9.svg")},55376,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(48962).default,width:192,height:192}}];

//# sourceMappingURL=app_8a35155e._.js.map