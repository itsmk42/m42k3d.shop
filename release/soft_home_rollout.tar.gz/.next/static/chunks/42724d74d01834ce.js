__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/44052874db3a7238.js",
  "static/chunks/turbopack-ef7cd6306400badb.js"
])
