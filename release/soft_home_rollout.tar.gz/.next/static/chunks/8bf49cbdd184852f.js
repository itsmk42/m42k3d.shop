__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/44052874db3a7238.js",
  "static/chunks/turbopack-0984988f0d4be1de.js"
])
